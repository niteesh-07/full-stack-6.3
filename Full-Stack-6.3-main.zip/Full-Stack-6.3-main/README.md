# Full-Stack-6.3
<img width="1920" height="1080" alt="Screenshot (40)" src="https://github.com/user-attachments/assets/db373fbc-1809-47db-b455-899020aa6740" />
<img width="1920" height="1080" alt="Screenshot (38)" src="https://github.com/user-attachments/assets/10a99f3f-1622-4018-9abc-4bd206ed79c3" />
<img width="1920" height="1080" alt="Screenshot (39)" src="https://github.com/user-attachments/assets/7771cccd-4fe4-4a48-9559-ac5de686d52f" />
